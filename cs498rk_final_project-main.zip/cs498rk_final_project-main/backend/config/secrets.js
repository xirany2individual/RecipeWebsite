/*
 * You generally want to .gitignore this file to prevent important credentials from being stored on your public repo.
 */
module.exports = {
    token : "secret-starter-mern",
    // mongo_connection : "YOUR URL TO MONGODB"
    mongo_connection : "mongodb+srv://testUser:cs498rk@cluster0.kkyqz.mongodb.net/cs498rk_final?retryWrites=true&w=majority"
};
